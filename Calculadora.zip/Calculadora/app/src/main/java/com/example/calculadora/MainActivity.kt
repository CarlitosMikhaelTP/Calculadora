package com.example.calculadora

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var num1: EditText
    private lateinit var num2: EditText
    private lateinit var resp: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num1 = findViewById(R.id.tv_num1)
        num2 = findViewById(R.id.tv_num2)


        // Configura los listeners de los botones
        val btnSumar: Button = findViewById(R.id.btnSumar)
        val btnRestar: Button = findViewById(R.id.btnRestar)
        val btnMult: Button = findViewById(R.id.btnMult)
        val btnDividir: Button = findViewById(R.id.btnDividir)
        val btnIgual: Button = findViewById(R.id.btnIgual)
        val btnPunto: Button = findViewById(R.id.btnPunto)
        val btnBorrar: Button = findViewById(R.id.btnBorrar)
        val btn0: Button = findViewById(R.id.btn0)
        val btn1: Button = findViewById(R.id.btn1)
        val btn2: Button = findViewById(R.id.btn2)
        val btn3: Button = findViewById(R.id.btn3)
        val btn4: Button = findViewById(R.id.btn4)
        val btn5: Button = findViewById(R.id.btn5)
        val btn6: Button = findViewById(R.id.btn6)
        val btn7: Button = findViewById(R.id.btn7)
        val btn8: Button = findViewById(R.id.btn8)
        val btn9: Button = findViewById(R.id.btn9)


        btnIgual.setOnClickListener {
            calcular("=")
        }

        btnPunto.setOnClickListener {
            calcular(".")
        }

        btn0.setOnClickListener {
            calcular("0")
        }

        btn1.setOnClickListener {
            calcular("1")
        }

        btn2.setOnClickListener {
            calcular("2")
        }

        btn3.setOnClickListener {
            calcular("3")
        }

        btn4.setOnClickListener {
            calcular("4")
        }

        btn5.setOnClickListener {
            calcular("5")
        }

        btn6.setOnClickListener {
            calcular("6")
        }

        btn7.setOnClickListener {
            calcular("7")
        }

        btn8.setOnClickListener {
            calcular("8")
        }

        btn9.setOnClickListener {
            calcular("9")
        }

        btnSumar.setOnClickListener {
            calcular("+")
        }

        btnRestar.setOnClickListener {
            calcular("-")
        }

        btnMult.setOnClickListener {
            calcular("*")
        }

        btnDividir.setOnClickListener {
            calcular("/")
        }

        btnBorrar.setOnClickListener {
            calcular("x")
        }
    }

    private fun calcular(operador: String) {

        val numero1 = num1.text.toString().toDouble()
        val numero2 = num2.text.toString().toDouble()

        var resultado = 0.0

        when (operador) {
            "+" -> resultado = numero1 + numero2
            "-" -> resultado = numero1 - numero2
            "*" -> resultado = numero1 * numero2
            "/" -> {
                if (numero2 != 0.0) {
                    resultado = numero1 / numero2
                } else {
                    resp.text = "Error: División por cero"
                    return
                }
            }
            "." -> resultado = numero1 + numero2
            "=" -> resultado = numero1 + numero2
            "0" -> resultado = numero1 + numero2
            "1" -> resultado = numero1 + numero2
            "2" -> resultado = numero1 + numero2
            "3" -> resultado = numero1 + numero2
            "4" -> resultado = numero1 + numero2
            "5" -> resultado = numero1 + numero2
            "6" -> resultado = numero1 + numero2
            "7" -> resultado = numero1 + numero2
            "8" -> resultado = numero1 + numero2
            "9" -> resultado = numero1 + numero2

        }

        resp.text = resultado.toString()
    }
}
